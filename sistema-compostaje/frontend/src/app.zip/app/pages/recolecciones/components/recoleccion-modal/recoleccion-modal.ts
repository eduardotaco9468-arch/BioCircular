import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Recoleccion } from '../../interfaces/recoleccion.interface';
import { RecoleccionForm } from '../recoleccion-form/recoleccion-form';

@Component({ selector: 'app-recoleccion-modal', standalone: true, imports: [RecoleccionForm], templateUrl: './recoleccion-modal.html', styleUrl: './recoleccion-modal.css' })
export class RecoleccionModal {
  @Input() recoleccionEditar: Recoleccion | null = null;
  @Output() cerrar = new EventEmitter<void>();
  @Output() guardar = new EventEmitter<Omit<Recoleccion, 'id'>>();
  cerrarModal(): void { this.cerrar.emit(); }
  guardarRecoleccion(recoleccion: Omit<Recoleccion, 'id'>): void { this.guardar.emit(recoleccion); }
}
