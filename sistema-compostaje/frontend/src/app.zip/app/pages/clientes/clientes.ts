import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { ClienteMockService } from './services/cliente-mock.service';
import { Cliente } from './interfaces/cliente.interface';
import { ToastService } from '../../core/services/toast.service';

import { ClienteModal } from './components/cliente-modal/cliente-modal';


@Component({

  selector: 'app-clientes',

  standalone: true,

  imports: [
    FormsModule,
    ClienteModal
  ],

  templateUrl: './clientes.html',

  styleUrl: './clientes.css'

})
export class Clientes implements OnInit {


  clientes: Cliente[] = [];

  clientesFiltrados: Cliente[] = [];


  busqueda:string = '';

  tipoSeleccionado:string = '';


  mostrarModal:boolean = false;

  clienteSeleccionado:any = null;

  constructor(

  private clienteService: ClienteMockService,

  private toastService: ToastService

  ){}



  ngOnInit(): void {


    this.clientes = this.clienteService.getClientes();

    this.clientesFiltrados = this.clientes;


  }



  abrirModal(){


    console.log('Botón funcionando');


    this.mostrarModal = true;


  }



  cerrarModal(){


  this.mostrarModal = false;


  this.clienteSeleccionado = null;


  }

  editarCliente(cliente:any){


    console.log(
      'Editar cliente:',
      cliente
    );


    this.clienteSeleccionado = cliente;


    this.mostrarModal = true;


  }

  eliminarCliente(cliente: Cliente){


    const confirmar = confirm(
      `¿Está seguro de eliminar a ${cliente.nombre}?`
    );


    if(confirmar){


      this.clientes =
      this.clientes.filter(
        c => c.id !== cliente.id
      );
      this.toastService.danger(
      'Cliente eliminado correctamente'
      );


      this.clientesFiltrados =
      this.clientes;


      console.log(
        'Cliente eliminado:',
        cliente
      );


    }


  }

  guardarCliente(cliente:any){


    // EDITAR
    if(this.clienteSeleccionado){


      const index = this.clientes.findIndex(
        c => c.id === this.clienteSeleccionado.id
      );


      if(index !== -1){


        this.clientes[index] = {


          ...this.clienteSeleccionado,

          ...cliente


        };
        this.toastService.info(
        'Cliente actualizado correctamente'
        );


      }


    }

    // CREAR
    else{


      const nuevoCliente = {


        id: this.clientes.length + 1,


        ...cliente


      };


      this.clientes.push(nuevoCliente);
      this.toastService.success(
      'Cliente creado correctamente'
      );


    }



    this.clientesFiltrados = [
      ...this.clientes
    ];



    this.clienteSeleccionado = null;


    this.cerrarModal();


  }



  filtrarClientes(){


    this.clientesFiltrados = this.clientes.filter(cliente => {


      const coincideNombre =
      cliente.nombre
      .toLowerCase()
      .includes(
        this.busqueda.toLowerCase()
      );



      const coincideTipo =
      this.tipoSeleccionado === ''
      ||
      cliente.tipo === this.tipoSeleccionado;



      return coincideNombre && coincideTipo;


    });


  }


}