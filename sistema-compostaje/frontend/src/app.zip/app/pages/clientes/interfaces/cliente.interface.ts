export interface Cliente {

    id:number;

    nombre:string;

    cedula:string;

    telefono:string;

    direccion:string;

    sector:string;

    tipo:string;

    estado:boolean;

}