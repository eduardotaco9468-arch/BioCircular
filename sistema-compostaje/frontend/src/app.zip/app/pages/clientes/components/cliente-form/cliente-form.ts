import { Component, EventEmitter, Input, Output, OnChanges, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';


@Component({
  selector: 'app-cliente-form',
  standalone: true,
  imports: [
    ReactiveFormsModule
  ],
  templateUrl: './cliente-form.html',
  styleUrl: './cliente-form.css'
})
export class ClienteForm implements OnChanges {
  @Input()
  clienteEditar:any = null;


  @Output()
  guardarCliente = new EventEmitter<any>();



  clienteForm: FormGroup;
  
  ngOnChanges(changes: SimpleChanges): void {


    if(this.clienteEditar){


      this.clienteForm.patchValue({

        nombre:this.clienteEditar.nombre,

        cedula:this.clienteEditar.cedula,

        telefono:this.clienteEditar.telefono,

        direccion:this.clienteEditar.direccion,

        sector:this.clienteEditar.sector,

        tipo:this.clienteEditar.tipo,

        estado:this.clienteEditar.estado

      });


    }


  }



  constructor(
    private fb: FormBuilder
  ){


    this.clienteForm = this.fb.group({


      nombre:[
        '',
        [
          Validators.required
        ]
      ],


      cedula:[
        '',
        [
          Validators.required
        ]
      ],


      telefono:[
        ''
      ],


      direccion:[
        ''
      ],


      sector:[
        '',
        [
          Validators.required
        ]
      ],


      tipo:[
        'Residencial',
        [
          Validators.required
        ]
      ],


      estado:[
        true
      ]


    });


  }



  guardar(){


    if(this.clienteForm.valid){


      this.guardarCliente.emit(
        this.clienteForm.value
      );


      this.clienteForm.reset({

        tipo:'Residencial',

        estado:true

      });


    }


  }


}