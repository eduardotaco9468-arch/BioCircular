import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ToastService } from '../../core/services/toast.service';
import { RutaModal } from './components/ruta-modal/ruta-modal';
import { Ruta } from './interfaces/ruta.interface';
import { RutaMockService } from './services/ruta-mock.service';

@Component({ selector: 'app-rutas', standalone: true, imports: [FormsModule, RutaModal], templateUrl: './rutas.html', styleUrl: './rutas.css' })
export class Rutas implements OnInit {
  rutas: Ruta[] = [];
  rutasFiltradas: Ruta[] = [];
  busqueda = '';
  sectorSeleccionado = '';
  mostrarModal = false;
  rutaSeleccionada: Ruta | null = null;

  constructor(private rutaService: RutaMockService, private toastService: ToastService) {}
  ngOnInit(): void { this.actualizarListado(); }
  abrirModal(): void { this.rutaSeleccionada = null; this.mostrarModal = true; }
  cerrarModal(): void { this.mostrarModal = false; this.rutaSeleccionada = null; }
  editarRuta(ruta: Ruta): void { this.rutaSeleccionada = { ...ruta }; this.mostrarModal = true; }

  eliminarRuta(ruta: Ruta): void {
    if (confirm(`¿Está seguro de eliminar la ruta ${ruta.nombre}?`) && this.rutaService.eliminarRuta(ruta.id)) {
      this.actualizarListado();
      this.toastService.danger('Ruta eliminada correctamente');
    }
  }

  guardarRuta(ruta: Omit<Ruta, 'id'>): void {
    if (this.rutaSeleccionada) {
      this.rutaService.actualizarRuta(this.rutaSeleccionada.id, ruta);
      this.toastService.info('Ruta actualizada correctamente');
    } else {
      this.rutaService.crearRuta(ruta);
      this.toastService.success('Ruta creada correctamente');
    }
    this.cerrarModal();
    this.actualizarListado();
  }

  filtrarRutas(): void {
    const termino = this.busqueda.toLowerCase().trim();
    this.rutasFiltradas = this.rutas.filter(ruta => {
      const coincideBusqueda = !termino || [ruta.nombre, ruta.sector, ruta.operador, ruta.horario].some(valor => valor.toLowerCase().includes(termino));
      return coincideBusqueda && (!this.sectorSeleccionado || ruta.sector === this.sectorSeleccionado);
    });
  }

  private actualizarListado(): void { this.rutas = this.rutaService.getRutas(); this.filtrarRutas(); }
}
