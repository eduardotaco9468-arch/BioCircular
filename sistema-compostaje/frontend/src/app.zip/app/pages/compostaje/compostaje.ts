import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ToastService } from '../../core/services/toast.service';
import { CompostajeModal } from './components/compostaje-modal/compostaje-modal';
import { Compostaje } from './interfaces/compostaje.interface';
import { CompostajeMockService } from './services/compostaje-mock.service';

@Component({ selector: 'app-compostaje', standalone: true, imports: [FormsModule, CompostajeModal], templateUrl: './compostaje.html', styleUrl: './compostaje.css' })
export class CompostajeComponent implements OnInit {
  compostajes: Compostaje[] = [];
  compostajesFiltrados: Compostaje[] = [];
  busqueda = '';
  estadoSeleccionado = '';
  mostrarModal = false;
  compostajeSeleccionado: Compostaje | null = null;
  constructor(private compostajeService: CompostajeMockService, private toastService: ToastService) {}
  ngOnInit(): void { this.actualizarListado(); }
  abrirModal(): void { this.compostajeSeleccionado = null; this.mostrarModal = true; }
  cerrarModal(): void { this.mostrarModal = false; this.compostajeSeleccionado = null; }
  editarCompostaje(registro: Compostaje): void { this.compostajeSeleccionado = { ...registro }; this.mostrarModal = true; }
  eliminarCompostaje(registro: Compostaje): void { if (confirm(`¿Está seguro de eliminar el ${registro.lote}?`) && this.compostajeService.eliminarCompostaje(registro.id)) { this.actualizarListado(); this.toastService.danger('Registro de compostaje eliminado correctamente'); } }
  guardarCompostaje(registro: Omit<Compostaje, 'id'>): void { if (this.compostajeSeleccionado) { this.compostajeService.actualizarCompostaje(this.compostajeSeleccionado.id, registro); this.toastService.info('Registro de compostaje actualizado correctamente'); } else { this.compostajeService.crearCompostaje(registro); this.toastService.success('Registro de compostaje creado correctamente'); } this.cerrarModal(); this.actualizarListado(); }
  filtrarCompostajes(): void { const termino = this.busqueda.toLowerCase().trim(); this.compostajesFiltrados = this.compostajes.filter(registro => (!termino || [registro.lote, registro.proceso, registro.observaciones].some(valor => valor.toLowerCase().includes(termino))) && (!this.estadoSeleccionado || registro.estado === this.estadoSeleccionado)); }
  claseEstado(estado: string): string { return estado === 'Activo' ? 'bg-success' : estado === 'Finalizado' ? 'bg-secondary' : 'bg-warning text-dark'; }
  private actualizarListado(): void { this.compostajes = this.compostajeService.getCompostajes(); this.filtrarCompostajes(); }
}
