import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Compostaje } from '../../interfaces/compostaje.interface';
import { CompostajeForm } from '../compostaje-form/compostaje-form';

@Component({ selector: 'app-compostaje-modal', standalone: true, imports: [CompostajeForm], templateUrl: './compostaje-modal.html', styleUrl: './compostaje-modal.css' })
export class CompostajeModal {
  @Input() compostajeEditar: Compostaje | null = null;
  @Output() cerrar = new EventEmitter<void>();
  @Output() guardar = new EventEmitter<Omit<Compostaje, 'id'>>();
  cerrarModal(): void { this.cerrar.emit(); }
  guardarCompostaje(registro: Omit<Compostaje, 'id'>): void { this.guardar.emit(registro); }
}
