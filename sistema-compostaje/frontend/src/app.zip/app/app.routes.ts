import { Routes } from '@angular/router';

import { MainLayout } from './layout/main-layout/main-layout';

import { Dashboard } from './pages/dashboard/dashboard';
import { Login } from './pages/auth/login/login';
import { Clientes } from './pages/clientes/clientes';   


export const routes: Routes = [

    {
        path:'login',
        component: Login
    },


    {
        path:'',
        component: MainLayout,
        children:[

            {
                path:'',
                redirectTo:'dashboard',
                pathMatch:'full'
            },

            {
                path:'dashboard',
                component: Dashboard
            },
            {
                path:'clientes',
                component:Clientes
            }

        ]
    },


    {
        path:'**',
        redirectTo:'dashboard'
    }

];